# Bài 4: Nginx chạy song song 2 cổng (8080, 8090)

## Cấu trúc
- `multi-port.conf` : cấu hình Nginx (2 server block)
- `beta-app/html/index.html` : trang Beta App (cổng 8080)
- `internal-app/html/index.html` : trang Internal App (cổng 8090)
- `setup.sh` : script cài đặt tự động

## Cách chạy trên server
```bash
unzip ex4.zip
cd ex4
sudo bash setup.sh
```

## Firewall nhà cung cấp (azPVS)
Mở Inbound TCP 8080 và 8090 (nguồn 0.0.0.0/0) nếu azPVS có mục firewall.

## Kiểm tra
```bash
curl http://<IP_MAY_CHU>:8080   # Beta App
curl http://<IP_MAY_CHU>:8090   # Internal App
```

## Nộp bài
Đẩy thư mục này lên `homework/session_03/ex4/` trên GitHub.
